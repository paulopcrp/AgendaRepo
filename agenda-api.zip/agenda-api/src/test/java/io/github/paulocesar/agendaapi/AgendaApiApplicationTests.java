package io.github.paulocesar.agendaapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgendaApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
